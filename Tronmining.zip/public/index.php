<?php
/**
 * Tronmining - HYIP Script
 * Public entry point
 */

// Redirect to main index.php in root
require_once __DIR__ . '/../index.php'; 